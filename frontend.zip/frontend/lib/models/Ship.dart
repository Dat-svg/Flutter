class ShippingMethod {
  final String name;
  final String estimatedArrival;
  final double price;

  ShippingMethod({required this.name, required this.estimatedArrival, required this.price});
}